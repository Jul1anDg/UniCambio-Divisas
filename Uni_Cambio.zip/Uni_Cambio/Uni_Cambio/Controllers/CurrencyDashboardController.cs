﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Uni_Cambio.Models;

namespace Uni_Cambio.Controllers
{
    public class CurrencyDashboardController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public CurrencyDashboardController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // GET: CurrencyDashboard/GetCurrencyRates
        // Consulta la API y retorna las tasas en formato JSON.
        [HttpGet]
        public async Task<IActionResult> GetCurrencyRates()
        {
            try
            {
                string baseUrl = _configuration["ExchangeRateApi:BaseUrl"]; // Ejemplo: "https://api.exchangerate-api.com/v4/latest/USD"
                string apiKey = _configuration["ExchangeRateApi:ApiKey"];

                var client = _httpClientFactory.CreateClient();
                if (!string.IsNullOrEmpty(apiKey))
                {
                    client.DefaultRequestHeaders.Add("apikey", apiKey);
                }

                var response = await client.GetAsync(baseUrl);
                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest($"Error al obtener las tasas: {errorContent}");
                }
                var json = await response.Content.ReadAsStringAsync();
                var ratesResponse = JsonSerializer.Deserialize<CurrencyRatesResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return Json(ratesResponse);
            }
            catch (System.Exception ex)
            {
                return BadRequest($"Excepción: {ex.Message}");
            }
        }

        // GET: CurrencyDashboard/RealTimeBarGraph
        // Retorna la vista que muestra la gráfica de barras en tiempo real.
        public IActionResult RealTimeBarGraph()
        {
            return View();
        }
    }
}
