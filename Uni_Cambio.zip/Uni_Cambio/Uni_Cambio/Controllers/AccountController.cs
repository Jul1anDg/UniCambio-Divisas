﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Uni_Cambio.Models; // Asegúrate de que este namespace corresponda a tu proyecto

namespace Uni_Cambio.Controllers
{
    public class AccountController : Controller
    {
        private readonly UniCambioContext _context;

        public AccountController(UniCambioContext context)
        {
            _context = context;
        }

        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string cc, string password)
        {
            // Busca en la base de datos un usuario que coincida con la Cc y la contraseña.
            // IMPORTANTE: En un entorno real, las contraseñas deben estar hasheadas.
            var user = await _context.Employes
                .FirstOrDefaultAsync(e => e.Cc == cc && e.PasswordEmploye == password);

            if (user == null)
            {
                ModelState.AddModelError("", "Credenciales inválidas");
                return View();
            }

            // Crea los claims de identidad, incluyendo el rol del usuario.
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.NameEmploye),
                new Claim("Cc", user.Cc),
                new Claim(ClaimTypes.Role, user.IdRol.ToString()) // Guarda el rol del usuario
            };

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            // Define las propiedades de autenticación (por ejemplo, persistencia de la cookie)
            var authProperties = new AuthenticationProperties
            {
                IsPersistent = true
            };

            // Crea la cookie de autenticación
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            // Redirige al usuario según su rol (idRol)
            if (user.IdRol == 1)
            {
                // Por ejemplo, rol 1: Empleado
                return RedirectToAction("Index", "Dashboard");
            }
            else if (user.IdRol == 2)
            {
                // Por ejemplo, rol 2: Empleado
                return RedirectToAction("Index", "Employes1");
            }
            else
            {
                // Para otros roles o si no se especifica un caso particular, redirige al Home general.
                return RedirectToAction("RealTimeBarGraph", "CurrencyDashboard");
            }
        }

        // POST: /Account/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            // Cierra la sesión eliminando la cookie de autenticación.
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }
    }
}
