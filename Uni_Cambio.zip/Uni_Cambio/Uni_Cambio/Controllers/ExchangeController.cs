﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Uni_Cambio.Models; // Asegúrate de tener definido ExchangeRatesResponse en este namespace

namespace Uni_Cambio.Controllers
{
    public class ExchangeController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public ExchangeController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // GET: Exchange/GetRates
        // Consulta la API y retorna las tasas de cambio en formato JSON.
        [HttpGet]
        public async Task<IActionResult> GetRates()
        {
            string baseUrl = _configuration["ExchangeRateApi:BaseUrl"]; // Ej: "https://api.exchangerate-api.com/v4/latest/USD"
            string apiKey = _configuration["ExchangeRateApi:ApiKey"];

            var client = _httpClientFactory.CreateClient();
            if (!string.IsNullOrEmpty(apiKey))
            {
                client.DefaultRequestHeaders.Add("apikey", apiKey);
            }

            var response = await client.GetAsync(baseUrl);
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var ratesResponse = JsonSerializer.Deserialize<ExchangeRatesResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return Json(ratesResponse);
            }
            return BadRequest("Error al obtener las tasas de cambio");
        }

        // GET: Exchange/TrendCurrencies
        // Retorna la vista principal para mostrar las gráficas de tendencia.
        public IActionResult TrendCurrencies()
        {
            return View();
        }
    }
}
