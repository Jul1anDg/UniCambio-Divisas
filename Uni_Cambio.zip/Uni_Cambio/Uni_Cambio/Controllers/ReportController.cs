﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using Uni_Cambio.Models;

public class ReportController : Controller
{
    private readonly UniCambioContext _context;

    public ReportController(UniCambioContext context)
    {
        _context = context;
    }

    public ActionResult Index()
    {
        // Obtener todas las monedas únicas de origen y destino
        var allCurrencies = _context.CurrencyExchangeTransactions
            .Select(t => t.OriginCurrency)
            .Concat(_context.CurrencyExchangeTransactions
            .Select(t => t.DestinationCurrency))
            .Distinct()
            .ToList();

        ViewBag.Currencies = new SelectList(allCurrencies);
        return View(new List<CurrencyExchangeTransaction>());
    }

    [HttpPost]
    public ActionResult Index(string originCurrency, string destinationCurrency)
    {
        var query = _context.CurrencyExchangeTransactions.AsQueryable();

        // Aplicar filtros
        if (!string.IsNullOrEmpty(originCurrency))
            query = query.Where(t => t.OriginCurrency == originCurrency);

        if (!string.IsNullOrEmpty(destinationCurrency))
            query = query.Where(t => t.DestinationCurrency == destinationCurrency);

        var transactions = query.ToList();

        // Cálculos para el gráfico
        var totalTransactions = _context.CurrencyExchangeTransactions.Count();
        var selectedCount = transactions.Count;
        ViewBag.TotalTransactions = totalTransactions; // Nuevo ViewBag 
        ViewBag.SelectedPercentage = totalTransactions > 0 ?
       Math.Round((decimal)selectedCount / (decimal)totalTransactions * 100, 2) : 0;

        // Recargar lista de monedas
        var allCurrencies = _context.CurrencyExchangeTransactions
            .Select(t => t.OriginCurrency)
            .Concat(_context.CurrencyExchangeTransactions
            .Select(t => t.DestinationCurrency))
            .Distinct()
            .ToList();

        ViewBag.Currencies = new SelectList(allCurrencies);

        return View(transactions);
    }
}