﻿using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Uni_Cambio.Models;
using Uni_Cambio.ViewModels;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace Uni_Cambio.Controllers
{
    public class TransactionController : Controller
    {
        private readonly UniCambioContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public TransactionController(UniCambioContext context, IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // GET: Transaction/Calculator
        public IActionResult Calculator()
        {
            return View();
        }
        // GET: Transaction/History
        public async Task<IActionResult> History()
        {
            var transactions = await _context.CurrencyExchangeTransactions
                                            .OrderByDescending(t => t.TransactionDate)
                                            .ToListAsync();

            // Obtiene el rol desde los claims del usuario autenticado
            var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value;

            // Define el layout según el rol del usuario
            if (roleClaim == "1") // Empleado
            {
                ViewBag.Layout = "~/Views/Shared/LayoutEmpleado.cshtml";
            }
            else if (roleClaim == "2") // Analista u otro rol
            {
                ViewBag.Layout = "~/Views/Shared/LayoutAdmin.cshtml";
            }
            else if (roleClaim == "3")
            {
                ViewBag.Layout = "~/Views/Shared/LayoutAnalista.cshtml";
            }

            return View(transactions);
        }


        // GET: Transaction/History
        public async Task<IActionResult> HistoryAdmin(string week)
        {
            // Convertir el valor del input week ("YYYY-Www") a fechas de inicio y fin
            DateTime startDate;
            DateTime endDate;
            if (!string.IsNullOrEmpty(week))
            {
                var parts = week.Split("-W");
                int year = int.Parse(parts[0]);
                int weekNum = int.Parse(parts[1]);
                // Suponemos que la semana empieza el lunes.
                DateTime jan1 = new DateTime(year, 1, 1);
                int daysOffset = DayOfWeek.Monday - jan1.DayOfWeek;
                DateTime firstMonday = jan1.AddDays(daysOffset);
                if (firstMonday.Year < year)
                {
                    firstMonday = firstMonday.AddDays(7);
                }
                startDate = firstMonday.AddDays((weekNum - 1) * 7);
                endDate = startDate.AddDays(7);
            }
            else
            {
                startDate = DateTime.MinValue;
                endDate = DateTime.MaxValue;
            }

            var transactions = await _context.CurrencyExchangeTransactions
                .Where(t => t.TransactionDate >= startDate && t.TransactionDate < endDate)
                .ToListAsync();

            decimal totalCommission = transactions.Sum(t => t.CommissionAmount);

            var viewModel = new TransactionHistoryViewModel
            {
                Week = week,
                Transactions = transactions,
                TotalCommission = totalCommission
            };

            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return PartialView("_TransactionTable", viewModel);
            }
            return View("HistoryAdmin", viewModel);
        }


        // POST: Transaction/Calculator
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Calculator(CurrencyExchangeTransaction transaction)
        {
            if (!ModelState.IsValid)
            {
                return View(transaction);
            }

            // 1. Llama a la API de Exchange Rate para obtener las tasas (la base es USD)
            string baseUrl = _configuration["ExchangeRateApi:BaseUrl"]; // Ej: "https://api.exchangerate-api.com/v4/latest/USD"
            string apiKey = _configuration["ExchangeRateApi:ApiKey"];
            var client = _httpClientFactory.CreateClient();
            // Si la API requiere enviar la API key en el header:
            client.DefaultRequestHeaders.Add("apikey", apiKey);

            var response = await client.GetAsync(baseUrl);
            ExchangeRatesResponse ratesResponse = null;
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                ratesResponse = JsonSerializer.Deserialize<ExchangeRatesResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            else
            {
                ModelState.AddModelError("", "Error al obtener las tasas de cambio.");
                return View(transaction);
            }

            // 2. Asigna las tasas automáticamente
            // Tasa de la divisa de origen a USD:
            if (transaction.OriginCurrency.ToUpper() == "USD")
            {
                transaction.RateOriginToUSD = 1;
            }
            else if (ratesResponse.Rates.ContainsKey(transaction.OriginCurrency.ToUpper()))
            {
                transaction.RateOriginToUSD = 1 / ratesResponse.Rates[transaction.OriginCurrency.ToUpper()];
            }
            else
            {
                ModelState.AddModelError("", "La tasa para la divisa de origen no se encontró.");
                return View(transaction);
            }

            // Tasa de USD a la divisa destino:
            if (transaction.DestinationCurrency.ToUpper() == "USD")
            {
                transaction.RateUSDToDestination = 1;
            }
            else if (ratesResponse.Rates.ContainsKey(transaction.DestinationCurrency.ToUpper()))
            {
                transaction.RateUSDToDestination = ratesResponse.Rates[transaction.DestinationCurrency.ToUpper()];
            }
            else
            {
                ModelState.AddModelError("", "La tasa para la divisa de destino no se encontró.");
                return View(transaction);
            }

            // 3. Realiza los cálculos
            transaction.AmountInUSD = transaction.AmountInitial * transaction.RateOriginToUSD;
            decimal commissionRate = 0.05m; // 0.5%
            transaction.CommissionAmount = transaction.AmountInUSD * commissionRate;
            transaction.NetUSD = transaction.AmountInUSD - transaction.CommissionAmount;
            transaction.AmountConverted = transaction.NetUSD * transaction.RateUSDToDestination;
            transaction.TransactionDate = DateTime.Now;

            // 4. Guarda la transacción en la base de datos
            _context.CurrencyExchangeTransactions.Add(transaction);
            await _context.SaveChangesAsync();

            // 5. Retorna la vista de resultado
            return View("Result", transaction);
        }

        /////////////////PORCCENTAJES
        // Acción principal que carga la vista

        // Acción principal que carga la vista completa
        public IActionResult HistoryFrecuency()
        {
            var model = new TransactionReportViewModel
            {
                OriginCurrencies = _context.CurrencyExchangeTransactions
                    .Select(t => t.OriginCurrency)
                    .Distinct()
                    .ToList(),

                DestinationCurrencies = _context.CurrencyExchangeTransactions
                    .Select(t => t.DestinationCurrency)
                    .Distinct()
                    .ToList(),

                FilteredTransactions = _context.CurrencyExchangeTransactions.ToList(),

                TransactionPercentage = 100 // 100% inicial
            };

            return View(model);
        }

        // Acción para filtrado AJAX
        public IActionResult FilterTransactions(string originCurrency, string destinationCurrency)
        {
            var query = _context.CurrencyExchangeTransactions.AsQueryable();

            // Aplicar filtros
            if (!string.IsNullOrEmpty(originCurrency))
                query = query.Where(t => t.OriginCurrency == originCurrency);

            if (!string.IsNullOrEmpty(destinationCurrency))
                query = query.Where(t => t.DestinationCurrency == destinationCurrency);

            var filtered = query.ToList();
            var totalTransactions = _context.CurrencyExchangeTransactions.Count();

            var model = new TransactionReportViewModel
            {
                FilteredTransactions = filtered,
                TransactionPercentage = CalculatePercentage(filtered.Count, totalTransactions)
            };

            return PartialView("_TransactionTablePartial", model);
        }

        private decimal CalculatePercentage(int filteredCount, int totalCount)
        {
            return totalCount == 0 ? 0 : Math.Round((decimal)filteredCount / totalCount * 100, 2);
        }


    }
}

    

