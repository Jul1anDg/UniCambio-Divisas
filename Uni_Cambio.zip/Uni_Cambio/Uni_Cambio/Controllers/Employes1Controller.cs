﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Uni_Cambio.Models;

namespace Uni_Cambio.Controllers
{
    public class Employes1Controller : Controller
    {
        private readonly UniCambioContext _context;

        public Employes1Controller(UniCambioContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Dashboard()
        {
            // Ejemplo: obtener estadísticas para el dashboard
            var totalEmployees = await _context.Employes.CountAsync();
            var totalRoles = await _context.Rols.CountAsync();

            // Pasar la información a la vista usando ViewBag o un ViewModel
            ViewBag.TotalEmployees = totalEmployees;
            ViewBag.TotalRoles = totalRoles;

            return View();
        }
        // GET: Employes1
        public async Task<IActionResult> Index()
        {
            var uniCambioContext = _context.Employes.Include(e => e.IdRolNavigation);
            return View(await uniCambioContext.ToListAsync());
        }

        // GET: Employes1/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employe = await _context.Employes
                .Include(e => e.IdRolNavigation)
                .FirstOrDefaultAsync(m => m.IdEmploye == id);
            if (employe == null)
            {
                return NotFound();
            }

            return View(employe);
        }

        // GET: Employes1/Create
        public IActionResult Create()
        {
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "NameRol");
            return View();
        }

        // POST: Employes1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdEmploye,NameEmploye,LastName,TimeCreate,PasswordEmploye,Cc,IdRol")] Employe employe)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employe);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", employe.IdRol);
            return View(employe);
        }

        // GET: Employes1/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employe = await _context.Employes.FindAsync(id);
            if (employe == null)
            {
                return NotFound();
            }
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", employe.IdRol);
            return View(employe);
        }

        // POST: Employes1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEmploye,NameEmploye,LastName,TimeCreate,PasswordEmploye,Cc,IdRol")] Employe employe)
        {
            if (id != employe.IdEmploye)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employe);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeExists(employe.IdEmploye))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", employe.IdRol);
            return View(employe);
        }

        // GET: Employes1/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employe = await _context.Employes
                .Include(e => e.IdRolNavigation)
                .FirstOrDefaultAsync(m => m.IdEmploye == id);
            if (employe == null)
            {
                return NotFound();
            }

            return View(employe);
        }

        // POST: Employes1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employe = await _context.Employes.FindAsync(id);
            if (employe != null)
            {
                _context.Employes.Remove(employe);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        // GET: Employes1/SearchByCc
        // Permite buscar un empleado por cédula y muestra sus datos junto con las acciones del CRUD
        public async Task<IActionResult> SearchByCc(string cedula)
        {
            if (string.IsNullOrEmpty(cedula))
            {
                ViewBag.NoResults = "Por favor, ingresa una cédula para buscar.";
                return View();
            }

            var employee = await _context.Employes.FirstOrDefaultAsync(e => e.Cc == cedula);
            if (employee == null)
            {
                ViewBag.NoResults = $"No se encontró un empleado con la cédula {cedula}.";
            }
            else
            {
                ViewBag.Employee = employee;
            }
            return View();
        }
        private bool EmployeExists(int id)
        {
            return _context.Employes.Any(e => e.IdEmploye == id);
        }
    }
}
