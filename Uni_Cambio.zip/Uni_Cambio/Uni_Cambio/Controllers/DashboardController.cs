﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Uni_Cambio.Models;

namespace Uni_Cambio.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public DashboardController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // GET: Dashboard/Index
        public async Task<IActionResult> Index()
        {
            // Lee la URL base y la API key desde appsettings.json
            string baseUrl = _configuration["ExchangeRateApi:BaseUrl"];
            string apiKey = _configuration["ExchangeRateApi:ApiKey"];

            var client = _httpClientFactory.CreateClient();
            // Agrega la API key en los headers si es requerido por la API
            client.DefaultRequestHeaders.Add("apikey", apiKey);

            // Llama a la API
            var response = await client.GetAsync(baseUrl);

            ExchangeRatesResponse ratesResponse = null;
            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                ratesResponse = JsonSerializer.Deserialize<ExchangeRatesResponse>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            else
            {
                // Manejo de error: se crea una respuesta vacía o se puede implementar un manejo de excepciones adecuado
                ratesResponse = new ExchangeRatesResponse
                {
                    BaseCurrency = "USD",
                    Date = "",
                    Rates = new Dictionary<string, decimal>()
                };
            }

            // Filtra las divisas importantes (ajusta la lista según tus necesidades)
            var importantCurrencies = new Dictionary<string, decimal>();
            if (ratesResponse?.Rates != null)
            {
                foreach (var currency in new[] { "EUR", "GBP", "JPY", "AUD", "CAD", "COP" })
                {
                    if (ratesResponse.Rates.ContainsKey(currency))
                    {
                        importantCurrencies[currency] = ratesResponse.Rates[currency];
                    }
                }
            }

            // Pasa la información a la vista
            ViewBag.BaseCurrency = ratesResponse?.BaseCurrency;
            ViewBag.Date = ratesResponse?.Date;
            ViewBag.ImportantRates = importantCurrencies;

            return View();
        }
    }
}
