﻿using Microsoft.AspNetCore.Mvc;

namespace Uni_Cambio.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
    }
}
