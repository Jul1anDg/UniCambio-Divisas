﻿using Microsoft.AspNetCore.Mvc;

namespace CambioDivisas.Controllers
{
    public class ForgotPasswordController : Controller
    {
        public IActionResult ForgotPassword()
        {
            return View();
        }
    }
}
