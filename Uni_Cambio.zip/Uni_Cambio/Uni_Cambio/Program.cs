﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Uni_Cambio.Models;


var builder = WebApplication.CreateBuilder(args);

// 1. Servicios (Configuración inicial)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options => options.LoginPath = "/Account/Login");

builder.Services.AddControllersWithViews();

// 2. Base de datos (tu configuración existente)
builder.Services.AddDbContext<UniCambioContext>(opt => opt.UseSqlServer(
    builder.Configuration.GetConnectionString("Connection")
));

builder.Services.AddHttpClient();
var app = builder.Build();

// 4. Middleware (El orden ES CRUCIAL aquí)
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();


// 5. Autenticación y Autorización (Deben ir en este orden)
app.UseAuthentication(); // ✅ Asegúrate que está antes de UseAuthorization
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();