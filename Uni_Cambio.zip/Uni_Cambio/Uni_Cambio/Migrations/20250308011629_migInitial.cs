﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Uni_Cambio.Migrations
{
    /// <inheritdoc />
    public partial class migInitial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CurrencyExchangeTransactions",
                columns: table => new
                {
                    TransactionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransactionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    OriginCurrency = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    DestinationCurrency = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    AmountInitial = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RateOriginToUSD = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RateUSDToDestination = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurrencyExchangeTransactions", x => x.TransactionId);
                });

            migrationBuilder.CreateTable(
                name: "Rol",
                columns: table => new
                {
                    IdRol = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NameRol = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    DescriptionRol = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Rol__2A49584CDA152EDD", x => x.IdRol);
                });

            migrationBuilder.CreateTable(
                name: "Employe",
                columns: table => new
                {
                    IdEmploye = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NameEmploye = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    TimeCreate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    PasswordEmploye = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    CC = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    IdRol = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Employe__2ED3206464DF0157", x => x.IdEmploye);
                    table.ForeignKey(
                        name: "IdRol",
                        column: x => x.IdRol,
                        principalTable: "Rol",
                        principalColumn: "IdRol");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Employe_IdRol",
                table: "Employe",
                column: "IdRol");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CurrencyExchangeTransactions");

            migrationBuilder.DropTable(
                name: "Employe");

            migrationBuilder.DropTable(
                name: "Rol");
        }
    }
}
