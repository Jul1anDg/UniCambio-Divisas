﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Uni_Cambio.Migrations
{
    /// <inheritdoc />
    public partial class Migration2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "AmountConverted",
                table: "CurrencyExchangeTransactions",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "AmountInUSD",
                table: "CurrencyExchangeTransactions",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "CommissionAmount",
                table: "CurrencyExchangeTransactions",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "NetUSD",
                table: "CurrencyExchangeTransactions",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AmountConverted",
                table: "CurrencyExchangeTransactions");

            migrationBuilder.DropColumn(
                name: "AmountInUSD",
                table: "CurrencyExchangeTransactions");

            migrationBuilder.DropColumn(
                name: "CommissionAmount",
                table: "CurrencyExchangeTransactions");

            migrationBuilder.DropColumn(
                name: "NetUSD",
                table: "CurrencyExchangeTransactions");
        }
    }
}
