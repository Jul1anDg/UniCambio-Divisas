﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Uni_Cambio.Models
{
    public class CurrencyExchangeTransaction
    {
        [Key]
        public int TransactionId { get; set; }

        [Display(Name = "Fecha y Hora")]
        public DateTime TransactionDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "La divisa de origen es obligatoria.")]
        [Display(Name = "Divisa de Origen")]
        public string OriginCurrency { get; set; }

        [Required(ErrorMessage = "La divisa de destino es obligatoria.")]
        [Display(Name = "Divisa de Destino")]
        public string DestinationCurrency { get; set; }

        [Required(ErrorMessage = "El monto inicial es obligatorio.")]
        [Display(Name = "Monto Inicial")]
        public decimal AmountInitial { get; set; }

        // Tasas asignadas automáticamente desde la API (USD es la base)
        [Display(Name = "Tasa (Origen a USD)")]
        public decimal RateOriginToUSD { get; set; }

        [Display(Name = "Tasa (USD a Destino)")]
        public decimal RateUSDToDestination { get; set; }

        // Valores calculados y guardados en la base de datos
        [Display(Name = "Monto convertido a USD")]
        public decimal AmountInUSD { get; set; }

        [Display(Name = "Comisión (0.5%)")]
        public decimal CommissionAmount { get; set; }

        [Display(Name = "Monto Neto en USD")]
        public decimal NetUSD { get; set; }

        [Display(Name = "Monto Convertido a Divisa Destino")]
        public decimal AmountConverted { get; set; }
    }
}
