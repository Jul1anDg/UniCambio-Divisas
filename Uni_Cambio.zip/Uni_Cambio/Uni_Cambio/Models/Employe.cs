﻿using System;
using System.Collections.Generic;

namespace Uni_Cambio.Models;

public partial class Employe
{
    public int IdEmploye { get; set; }

    public string NameEmploye { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public DateTime? TimeCreate { get; set; }

    public string PasswordEmploye { get; set; } = null!;

    public string Cc { get; set; } = null!;

    public int IdRol { get; set; }

    public virtual Rol? IdRolNavigation { get; set; } = null!;
}
