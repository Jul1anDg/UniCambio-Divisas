﻿namespace Uni_Cambio.Models
{
    public class TransactionHistoryViewModel
    {
         // Almacena el valor de la semana seleccionada (formato "YYYY-Www")
            public string Week { get; set; }

            // Lista de transacciones filtradas
            public IEnumerable<CurrencyExchangeTransaction> Transactions { get; set; }

            // Total acumulado de comisiones
            public decimal TotalCommission { get; set; }
    }
}
