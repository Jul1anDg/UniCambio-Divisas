﻿namespace Uni_Cambio.Models
{
    public class ExchangeTransaction
    {
        public DateTime OperationDate { get; set; }
        public string BaseCurrency { get; set; }
        public string TargetCurrency { get; set; }
        public decimal Amount { get; set; }
        public decimal ExchangeRateApplied { get; set; }
    }

    public class ReportFilters
    {
        public DateTime? StartPeriod { get; set; }
        public DateTime? EndPeriod { get; set; }
        public string CurrencyFilter { get; set; }
    }
}