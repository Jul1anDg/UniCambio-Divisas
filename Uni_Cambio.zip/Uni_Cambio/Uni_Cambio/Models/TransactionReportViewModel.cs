﻿using System.Collections.Generic;
using Uni_Cambio.Models;

namespace Uni_Cambio.ViewModels
{
    public class TransactionReportViewModel
    {
        // Propiedades para filtros
        public string SelectedOrigin { get; set; }
        public string SelectedDestination { get; set; }

        // Listas para dropdowns
        public IEnumerable<string> OriginCurrencies { get; set; }
        public IEnumerable<string> DestinationCurrencies { get; set; }

        // Datos filtrados
        public IEnumerable<CurrencyExchangeTransaction> FilteredTransactions { get; set; }

        // Estadísticas
        public decimal TransactionPercentage { get; set; }
    }
}