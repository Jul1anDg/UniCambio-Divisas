﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Uni_Cambio.Models;

public partial class UniCambioContext : DbContext
{
    
    public UniCambioContext()
    {
    }

    public UniCambioContext(DbContextOptions<UniCambioContext> options)
        : base(options)
    {
    }
    // Agrega esta línea
    public virtual DbSet<Employe> Employes { get; set; }

    public virtual DbSet<Rol> Rols { get; set; }
    public DbSet<CurrencyExchangeTransaction> CurrencyExchangeTransactions { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=Connection");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employe>(entity =>
        {
            entity.HasKey(e => e.IdEmploye).HasName("PK__Employe__2ED3206464DF0157");

            entity.ToTable("Employe");

            entity.Property(e => e.Cc)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("CC");
            entity.Property(e => e.LastName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NameEmploye)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PasswordEmploye)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TimeCreate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.IdRolNavigation).WithMany(p => p.Employes)
                .HasForeignKey(d => d.IdRol)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("IdRol");
        });

        modelBuilder.Entity<Rol>(entity =>
        {
            entity.HasKey(e => e.IdRol).HasName("PK__Rol__2A49584CDA152EDD");

            entity.ToTable("Rol");

            entity.Property(e => e.DescriptionRol)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NameRol)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        //Configuración para la nueva entidad CurrencyExchangeTransaction
        modelBuilder.Entity<CurrencyExchangeTransaction>(entity =>
        {
            entity.ToTable("CurrencyExchangeTransactions");
            entity.HasKey(e => e.TransactionId);

            entity.Property(e => e.OriginCurrency)
                  .IsRequired()
                  .HasMaxLength(10);
            entity.Property(e => e.DestinationCurrency)
                  .IsRequired()
                  .HasMaxLength(10);
            entity.Property(e => e.AmountInitial)
                  .IsRequired();
            // Las propiedades RateOriginToUSD y RateUSDToDestination se asignan en el controlador
        });
        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
