﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Uni_Cambio.Models
{
    public class ExchangeRatesResponse
    {
        [JsonPropertyName("base")]
        public string BaseCurrency { get; set; }

        [JsonPropertyName("date")]
        public string Date { get; set; }

        [JsonPropertyName("rates")]
        public Dictionary<string, decimal> Rates { get; set; }
    }
}   