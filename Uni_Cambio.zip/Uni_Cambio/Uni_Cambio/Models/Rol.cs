﻿using System;
using System.Collections.Generic;

namespace Uni_Cambio.Models;

public partial class Rol
{
    public int IdRol { get; set; }

    public string NameRol { get; set; } = null!;

    public string? DescriptionRol { get; set; }

    public virtual ICollection<Employe> Employes { get; set; } = new List<Employe>();
}
