﻿using System;

namespace Uni_Cambio.Models
{
    public class Transaccion
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public string MonedaOrigen { get; set; }
        public string MonedaDestino { get; set; }
        public decimal Monto { get; set; }
        public decimal Comision { get; set; }
    }
}